Flask-Bcrypt
------------

Bcrypt hashing for your Flask.


